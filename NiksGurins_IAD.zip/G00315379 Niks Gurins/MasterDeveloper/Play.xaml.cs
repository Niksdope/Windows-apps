﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace MasterDeveloper
{
    public partial class Page2 : PhoneApplicationPage
    {
        List<string> cards = new List<string>();

        public Page2()
        {
            Globals.counter = 0;
            Globals.computerValue = 0;
            Globals.playerValue = 0;

            InitializeComponent();
            populateArray();
            startDraw();
            buttonAgain.Visibility = System.Windows.Visibility.Collapsed;
            buttonQuit.Visibility = System.Windows.Visibility.Collapsed;
        }

        public void populateArray()
        { 
            for(int i=1;i<53;i++)
            {
                cards.Add("Cards/" + i + ".png");             
            }                                                                                                                                                            
        }

        public void buttonHit_Click(object sender, RoutedEventArgs e)
        {
            String imgName;
            Image imgSource;
            Uri imgURI;
            BitmapImage imgBitmap;

            Globals.counter++;

            cardDraw();

            textBlockComp.Text = "Computer card value: " + Globals.computerValue;
            textBlockPlayer.Text = "Player card value: " + Globals.playerValue;

            if (Globals.playerValue > 21)
            {
                Globals.counter = 0;
                computerDraw();

                imgName = "outcomeImage";
                imgSource = (Image)FindName(imgName);

                imgURI = new Uri("Images/bust.png", UriKind.RelativeOrAbsolute);
                imgBitmap = new BitmapImage(imgURI);
                imgSource.Source = imgBitmap;

                textBlockPlayer.Text = "" + Globals.playerValue;
                textBlockComp.Text = "" + Globals.computerValue;

                buttonHit.Visibility = System.Windows.Visibility.Collapsed;
                buttonStay.Visibility = System.Windows.Visibility.Collapsed;
                buttonAgain.Visibility = System.Windows.Visibility.Visible;
                buttonQuit.Visibility = System.Windows.Visibility.Visible;
            }
        }

        public void cardDraw()
        {
            int num;
            string cardName;
            Image nextImage;
            Uri picURI;
            BitmapImage myBitmap;

            Random number = new Random();

            if (Globals.counter == 1)
            {
                num = number.Next(1, 52);

                Globals.playerCardNum = num;

                playerCardValue();

                cardName = "playerCard3".ToString();
                nextImage = (Image)FindName(cardName);

                picURI = new Uri("Cards/" + num + ".png", UriKind.RelativeOrAbsolute);
                myBitmap = new BitmapImage(picURI);
                nextImage.Source = myBitmap;
            }
            else if (Globals.counter == 2)
            {
                num = number.Next(1, 52);

                Globals.playerCardNum = num;

                playerCardValue();

                cardName = "playerCard4".ToString();
                nextImage = (Image)FindName(cardName);

                picURI = new Uri("Cards/" + num + ".png", UriKind.RelativeOrAbsolute);
                myBitmap = new BitmapImage(picURI);
                nextImage.Source = myBitmap;
            }
            else if (Globals.counter == 3)
            {
                num = number.Next(1, 52);

                Globals.playerCardNum = num;

                playerCardValue();

                cardName = "playerCard5".ToString();
                nextImage = (Image)FindName(cardName);

                picURI = new Uri("Cards/" + num + ".png", UriKind.RelativeOrAbsolute);
                myBitmap = new BitmapImage(picURI);
                nextImage.Source = myBitmap;
            }
            else
            {
                buttonHit.Visibility = System.Windows.Visibility.Collapsed;
            }
        }
        public void playerCardValue ()
        {
            switch (Globals.playerCardNum)
            {
                case 49:
                case 50:
                case 51:
                case 52:
                    Globals.playerValue += 2;
                    break;
                case 45:
                case 46:
                case 47:
                case 48:
                    Globals.playerValue += 3;
                    break;
                case 41:
                case 42:
                case 43:
                case 44:
                    Globals.playerValue += 4;
                    break;
                case 37:
                case 38:
                case 39:
                case 40:
                    Globals.playerValue += 5;
                    break;
                case 33:
                case 34:
                case 35:
                case 36:
                    Globals.playerValue += 6;
                    break;
                case 29:
                case 30:
                case 31:
                case 32:
                    Globals.playerValue += 7;
                    break;
                case 25:
                case 26:
                case 27:
                case 28:
                    Globals.playerValue += 8;
                    break;
                case 21:
                case 22:
                case 23:
                case 24:
                    Globals.playerValue += 9;
                    break;
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                case 11:
                case 12:
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 18:
                case 19:
                case 20:
                    Globals.playerValue += 10;
                    break;
                case 1:
                case 2:
                case 3:
                case 4: 
                    if (Globals.playerValue <= 10)
                    {
                        Globals.playerValue += 11;
                    }
                    else
                    {
                        Globals.playerValue += 1;
                    }
                    break;
            }
        }

        public void computerCardValue()
        {
            switch (Globals.computerCardNum)
            {
                case 49:
                case 50:
                case 51:
                case 52:
                    Globals.computerValue += 2;
                    break;
                case 45:
                case 46:
                case 47:
                case 48:
                    Globals.computerValue += 3;
                    break;
                case 41:
                case 42:
                case 43:
                case 44:
                    Globals.computerValue += 4;
                    break;
                case 37:
                case 38:
                case 39:
                case 40:
                    Globals.computerValue += 5;
                    break;
                case 33:
                case 34:
                case 35:
                case 36:
                    Globals.computerValue += 6;
                    break;
                case 29:
                case 30:
                case 31:
                case 32:
                    Globals.computerValue += 7;
                    break;
                case 25:
                case 26:
                case 27:
                case 28:
                    Globals.computerValue += 8;
                    break;
                case 21:
                case 22:
                case 23:
                case 24:
                    Globals.computerValue += 9;
                    break;
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                case 11:
                case 12:
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 18:
                case 19:
                case 20:
                    Globals.computerValue += 10;
                    break;
                case 1:
                case 2:
                case 3:
                case 4:
                    if (Globals.computerValue <= 10)
                    {
                        Globals.computerValue += 11;
                    }
                    else
                    {
                        Globals.computerValue += 1;
                    }
                    break;
            }
        }

        private void buttonStay_Click(object sender, RoutedEventArgs e)
        {
            buttonHit.Visibility = System.Windows.Visibility.Collapsed;

            int x = 0;
            string imgName;
            Image imgSource;
            Uri imgURI;
            BitmapImage imgBitmap;

            Globals.counter = 0;

            do
            {
                computerDraw();

                if (Globals.computerValue > Globals.playerValue && Globals.playerValue < 22 && Globals.computerValue < 22)
                {
                    x = 1;

                    imgName = "outcomeImage";
                    imgSource = (Image)FindName(imgName);

                    imgURI = new Uri("Images/house.png", UriKind.RelativeOrAbsolute);
                    imgBitmap = new BitmapImage(imgURI);
                    imgSource.Source = imgBitmap;

                    textBlockPlayer.Text = "" + Globals.playerValue;
                    textBlockComp.Text = "" + Globals.computerValue;

                    buttonHit.Visibility = System.Windows.Visibility.Collapsed;
                    buttonStay.Visibility = System.Windows.Visibility.Collapsed;
                    buttonAgain.Visibility = System.Windows.Visibility.Visible;
                    buttonQuit.Visibility = System.Windows.Visibility.Visible;
                }
                else if (Globals.computerValue == 21 && Globals.playerValue < 21)
                {
                    x = 1;

                    imgName = "outcomeImage";
                    imgSource = (Image)FindName(imgName);

                    imgURI = new Uri("Images/house.png", UriKind.RelativeOrAbsolute);
                    imgBitmap = new BitmapImage(imgURI);
                    imgSource.Source = imgBitmap;

                    textBlockPlayer.Text = "" + Globals.playerValue;
                    textBlockComp.Text = "" + Globals.computerValue;

                    buttonHit.Visibility = System.Windows.Visibility.Collapsed;
                    buttonStay.Visibility = System.Windows.Visibility.Collapsed;
                    buttonAgain.Visibility = System.Windows.Visibility.Visible;
                    buttonQuit.Visibility = System.Windows.Visibility.Visible;
                }
                else if (Globals.computerValue > 21 && Globals.playerValue < 22)
                {
                    x = 1;

                    imgName = "outcomeImage";
                    imgSource = (Image)FindName(imgName);

                    imgURI = new Uri("Images/houseBust.png", UriKind.RelativeOrAbsolute);
                    imgBitmap = new BitmapImage(imgURI);
                    imgSource.Source = imgBitmap;

                    textBlockPlayer.Text = "" + Globals.playerValue;
                    textBlockComp.Text = "" + Globals.computerValue;

                    buttonHit.Visibility = System.Windows.Visibility.Collapsed;
                    buttonStay.Visibility = System.Windows.Visibility.Collapsed;
                    buttonAgain.Visibility = System.Windows.Visibility.Visible;
                    buttonQuit.Visibility = System.Windows.Visibility.Visible;
                }
                else if (Globals.playerValue == 21 && Globals.computerValue == 21)
                {
                    x = 1;

                    imgName = "outcomeImage";
                    imgSource = (Image)FindName(imgName);

                    imgURI = new Uri("Images/push.png", UriKind.RelativeOrAbsolute);
                    imgBitmap = new BitmapImage(imgURI);
                    imgSource.Source = imgBitmap;

                    textBlockPlayer.Text = "" + Globals.playerValue;
                    textBlockComp.Text = "" + Globals.computerValue;

                    buttonHit.Visibility = System.Windows.Visibility.Collapsed;
                    buttonStay.Visibility = System.Windows.Visibility.Collapsed;
                    buttonAgain.Visibility = System.Windows.Visibility.Visible;
                    buttonQuit.Visibility = System.Windows.Visibility.Visible;
                }
            } while (x != 1);

            buttonStay.Visibility = System.Windows.Visibility.Collapsed;
        }  //end buttonStay click event

        public void computerDraw()
        {
            int num;
            string cardName;
            Image nextImage;
            Uri picURI;
            BitmapImage myBitmap;

            Random number = new Random();

            num = number.Next(1, 52);

            Globals.computerCardNum = num;

            computerCardValue();

            cardName = "computerCard" + (Globals.counter + 2).ToString();
            nextImage = (Image)FindName(cardName);

            picURI = new Uri("Cards/" + num + ".png", UriKind.RelativeOrAbsolute);
            myBitmap = new BitmapImage(picURI);
            nextImage.Source = myBitmap;

            Globals.counter++;

            textBlockComp.Text = "Computer card value: " + Globals.computerValue;
        }

        public void startDraw()
        {
            int num;
            string cardName;
            Image nextImage;
            Uri picURI;
            BitmapImage myBitmap;

            Random number = new Random();


                for (int i = 1; i < 3; i++)
                {
                    num = number.Next(1, 52);

                    Globals.playerCardNum = num;

                    playerCardValue();

                    cardName = "playerCard" + i.ToString();
                    nextImage = (Image)FindName(cardName);
                    
                    picURI = new Uri("Cards/" + num + ".png", UriKind.RelativeOrAbsolute);
                    myBitmap = new BitmapImage(picURI);
                    nextImage.Source = myBitmap;

                    if (i == 1)
                    {
                        num = number.Next(1, 52);

                        Globals.computerCardNum = num;

                        computerCardValue();

                        cardName = "computerCard" + i.ToString();
                        nextImage = (Image)FindName(cardName);

                        picURI = new Uri("Cards/" + num + ".png", UriKind.RelativeOrAbsolute);
                        myBitmap = new BitmapImage(picURI);
                        nextImage.Source = myBitmap;
                    }

                } //end of for
                textBlockPlayer.Text = "Player card value: " + Globals.playerValue;
                textBlockComp.Text = "Computer card value: " + Globals.computerValue;

                if (Globals.playerValue == 21)
                {
                    buttonHit.Visibility = System.Windows.Visibility.Collapsed;
                }
        } //end startDraw();

        private void buttonAgain_Click(object sender, EventArgs e)
        {
            var ReloadUri = (((App)Application.Current).RootFrame.Content as PhoneApplicationPage).NavigationService.CurrentSource;
            (Application.Current.RootVisual as PhoneApplicationFrame).Navigate(new Uri(ReloadUri +"?no-cache="+Guid.NewGuid(), UriKind.Relative));
        }

        private void buttonQuit_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}